# Whack A Duck Shit

A Pen created on CodePen.io. Original URL: [https://codepen.io/Nalini1998/pen/dywGpXW/e42045317cfcccc9897fac08f3c7c5e9](https://codepen.io/Nalini1998/pen/dywGpXW/e42045317cfcccc9897fac08f3c7c5e9).

